#include <stdint.h>
#include "I2C0.h"            // I2C driver for TM4C
#include "CortexM.h"         // StartCritical/EndCritical definitions
#include "tm4c123gh6pm.h"    // Full register map for the Tiva C
#include "my_procs_at_ece_uccs.h"
#include "my_defines_at_ece_uccs.h"

/* 
 * Jeffrey Smith - ECE 3440-001 Spring 2026
 * Lab 3: Integrated I2C Driver & Interrupt-Driven Control
 * This program uses an I2C-based DIP switch to control a counter displayed 
 * on dual 7-segment displays, featuring a Watchdog safety and a Timer heartbeat.
 */

// --- Global Variables (Marked volatile because they are modified in ISRs) ---
volatile uint8_t g_ledState = 0;       // Tracks 3-bit pattern for RGB Heartbeat
volatile uint8_t g_countDirection = 0; // Direction toggle from DIP Switch 0
volatile uint8_t g_displayMode = 2;    // Display selection from DIP Switches 1-2
volatile uint8_t g_displayBase = 10;   // Selection (Dec/Hex) from DIP Switch 3
uint8_t g_currentCount = 0;            // Main counter incremented in while(1)

/* I2C Slave Addresses for PCF8574/MCP23008 IO Expanders */
#define I2C_ADDR_DIP        (0x20)     // Address for DIP Switch input bank
#define I2C_ADDR_7SEG_LOW   (0x21)     // Address for Right 7-segment display
#define I2C_ADDR_7SEG_HIGH  (0x22)     // Address for Left 7-segment display

/* 
 * Lookup Table: Common Anode 7-Segment Patterns
 * Logic 0 = Segment ON, Logic 1 = Segment OFF
 * Index matches hex value (0-F)
 */
static const uint8_t g_hexTo7Seg_CA[16] = {
    0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 
    0x80, 0x90, 0x88, 0x83, 0xC6, 0xA1, 0x86, 0x8E
};

// --- Function Prototypes ---
void OutputNumTo7Seg(unsigned int number_, unsigned char mode_, unsigned char base_);
void PortF_Init(void);
void PortE_Init(void);
void Watchdog_Init(void);
void Timer3A_Init(uint32_t period);

int main(void) {
    I2C_Init();             // Enable I2C0 Module at 100kbps
    PortF_Init();           // Setup Onboard RGB LEDs (PF1-PF3)
    PortE_Init();           // Setup External Interrupt on PE1 for DIP sensing
    Watchdog_Init();        // Prevent system hang (1s timeout)
    Timer3A_Init(16000000); // Initialize 1Hz periodic timer (Assuming 16MHz clock)

    while (1) {
        // Feed the Watchdog timer to prevent a system reset
        WATCHDOG0_ICR_R = 0xFFFFFFFF; 

        // 1. Update counter based on global direction set in GPIO ISR
        if (g_countDirection == 0) {
            g_currentCount++;
        } else {
            g_currentCount--;
        }

        // 2. Update hardware displays via I2C driver
        OutputNumTo7Seg(g_currentCount, g_displayMode, g_displayBase);

        // 3. Simple software delay for human readability (~4Hz update rate)
        for(volatile uint32_t i = 0; i < 400000; i++);
    }
}

/**
 * OutputNumTo7Seg: Updates I2C 7-Segment Displays
 * USES CRITICAL SECTIONS: Prevents the GPIO ISR from trying to use the I2C
 * bus while the main loop is mid-transmission (prevents bus collision).
 */
void OutputNumTo7Seg(unsigned int number_, unsigned char mode_, unsigned char base_) {
    uint8_t leftDigit, rightDigit;
    long sr; 

    // Extract digits based on selected base (10 for Decimal, 16 for Hex)
    rightDigit = number_ % base_;
    leftDigit  = (number_ / base_) % base_;

    // Disable interrupts to protect the I2C transaction sequence
    sr = StartCritical(); 

    if (mode_ == 0) {
        // Update Left display only
        I2C_Send1(I2C_ADDR_7SEG_HIGH, g_hexTo7Seg_CA[leftDigit]);
    } 
    else if (mode_ == 1) {
        // Update Right display only
        I2C_Send1(I2C_ADDR_7SEG_LOW, g_hexTo7Seg_CA[rightDigit]);
    } 
    else if (mode_ == 2) {
        // Update both displays
        I2C_Send1(I2C_ADDR_7SEG_HIGH, g_hexTo7Seg_CA[leftDigit]);
        I2C_Send1(I2C_ADDR_7SEG_LOW,  g_hexTo7Seg_CA[rightDigit]);
    }

    // Re-enable interrupts
    EndCritical(sr); 
}

/* 
 * GPIOPortE_Handler: Triggered by DIP switch change on PE1 
 * Reads the status of the I2C DIP Switch bank and updates control globals.
 */
void GPIOPortE_Handler(void) {
    GPIO_PORTE_ICR_R = 0x02; // Clear the interrupt flag for PE1
    
    // Perform I2C Read to get current switch positions
    uint8_t dipValue = I2C_Recv(I2C_ADDR_DIP);
    
    // Switch 0: Bit 0 determines Up/Down counting
    g_countDirection = (dipValue & 0x01);

    // Switch 1-2: Bits [2:1] determine display mode (Left/Right/Both)
    g_displayMode = (dipValue >> 1) & 0x03;
    if (g_displayMode > 2) g_displayMode = 2; // Safety clamp

    // Switch 3: Bit 3 determines numerical base
    g_displayBase = (dipValue & 0x08) ? 16 : 10;
}

/* 
 * Timer3A_Handler: 1Hz Heartbeat 
 * Cycles through a 3-bit color pattern on the onboard RGB LEDs.
 */
void Timer3A_Handler(void) {
    TIMER3_ICR_R = 0x01;            // Acknowledge Timer timeout
    g_ledState = (g_ledState + 1) & 0x07; // Increment state (0-7)
    
    uint8_t mask = 0;
    if (g_ledState & 0x01) mask |= 0x02; // Bit 0 -> Red LED (PF1)
    if (g_ledState & 0x02) mask |= 0x04; // Bit 1 -> Blue LED (PF2)
    if (g_ledState & 0x04) mask |= 0x08; // Bit 2 -> Green LED (PF3)
    
    // Use Bit-Masking through the data register to update only PF1-PF3
    GPIO_PORTF_DATA_BITS_R[0x0E] = mask;
}

// --- Initialization Functions ---

void PortF_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x20;            // Enable Clock for Port F
    while((SYSCTL_PRGPIO_R & 0x20) == 0){}; // Wait for stabilization
    GPIO_PORTF_DIR_R |= 0x0E;             // Set PF1, PF2, PF3 as outputs
    GPIO_PORTF_DEN_R |= 0x0E;             // Enable digital function
}

void PortE_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x10;            // Enable Clock for Port E
    while((SYSCTL_PRGPIO_R & 0x10) == 0){};// Wait for stabilization
    GPIO_PORTE_DIR_R  &= ~0x02;           // PE1 as input
    GPIO_PORTE_DEN_R  |=  0x02;           // Digital Enable PE1
    GPIO_PORTE_PUR_R  |=  0x02;           // Pull-up resistor for active-low switch
    GPIO_PORTE_IS_R   &= ~0x02;           // PE1 is edge-sensitive
    GPIO_PORTE_IBE_R  &= ~0x02;           // PE1 is not both edges
    GPIO_PORTE_IEV_R  &= ~0x02;           // PE1 falling edge trigger
    GPIO_PORTE_ICR_R   =  0x02;           // Clear initial flags
    GPIO_PORTE_IM_R   |=  0x02;           // Unmask (enable) interrupt for PE1
    
    // Set priority to 3 and enable IRQ 4 in NVIC
    NVIC_PRI1_R = (NVIC_PRI1_R & 0xFFFF00FF) | (3 << 13); 
    NVIC_EN0_R |= (1U << 4);
}

void Watchdog_Init(void) {
    SYSCTL_RCGCWD_R |= 0x01;              // Enable Watchdog 0 clock
    while((SYSCTL_PRWD_R & 0x01) == 0){};
    WATCHDOG0_LOCK_R = 0x1ACCE551;        // Unlock for configuration
    WATCHDOG0_LOAD_R = 16000000;          // 1 second at 16MHz
    WATCHDOG0_CTL_R |= 0x03;              // Enable reset and interrupt
    WATCHDOG0_LOCK_R = 0;                 // Re-lock
}

void Timer3A_Init(uint32_t period) {
    SYSCTL_RCGCTIMER_R |= 0x08;           // Enable Timer 3 clock
    while((SYSCTL_PRTIMER_R & 0x08) == 0){};
    TIMER3_CTL_R  &= ~0x01;               // Disable timer for setup
    TIMER3_CFG_R   = 0x00;                // 32-bit mode
    TIMER3_TAMR_R  = 0x02;                // Periodic mode
    TIMER3_TAILR_R = period - 1;          // Set interval
    TIMER3_ICR_R   = 0x01;                // Clear flag
    TIMER3_IMR_R  |= 0x01;                // Enable timeout interrupt
    
    // Set priority 1 (higher than Port E) and enable in NVIC
    NVIC_PRI8_R = (NVIC_PRI8_R & 0x00FFFFFF) | (1 << 29); 
    NVIC_EN1_R |= (1U << 3);
    TIMER3_CTL_R |= 0x01;                 // Start Timer 3A
}
