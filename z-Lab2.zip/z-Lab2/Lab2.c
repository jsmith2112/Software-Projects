#include <stdint.h>
#include "I2C0.h"
#include "CortexM.h"
#include "tm4c123gh6pm.h"
#include "my_procs_at_ece_uccs.h"
#include "my_defines_at_ece_uccs.h"

/* 
 * Jeffrey Smith
 * ECE 3440-001 Spring 2026
 * Assignment: Lab 2
 * Due Date: 2/17/2026
 *
 * Language: C
 * 1 second, 8 color LED Flash
 * using Timer 3A for ISR with 
 * Watchdog Timer enabled
 * LAB 2: I2C Interface with PCF8574 IO Expanders
 *
 * Constraints:
 * 1. Use Peripheral Ready (PR) registers instead of dummy reads for clock stability.
 * 2. Timer3A (1Hz LED toggle) must have higher priority than Port E (DIP switch).
 * 3. 7-Segment displays are Common Anode (Logic 0 turns a segment ON).
 * 
 * Answer Question: What is the interrupt number for Port E and how do you find it?
 * GPIO Port E interrupt number is 4
 * Found in the Tiva� TM4C123GH6PM Microcontroller Data Sheet
 * Table 2-9. Interrupts
 */

/*
 * Global variable for LED state (0�7)
 */
volatile uint8_t g_ledState = 0;

/* I2C Slave Addresses for PCF8574 (Base 0x20 + A2,A1,A0 pins) */
#define I2C_ADDR_DIP        (0x20)   // DIP Switch input expander
#define I2C_ADDR_7SEG_LOW   (0x21)   // Right 7-segment display
#define I2C_ADDR_7SEG_HIGH  (0x22)   // Left 7-segment display

/* Lookup Table: Bits [0-6] map to segments a-g. Bit 7 is DP.
   This table is Common Cathode; Will bitwise NOT (~) for Common Anode. */
static const uint8_t g_hexTo7Seg_CC[16] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 
    0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71
};

/* Function Prototypes */
void PortF_Init(void);
void PortE_Init(void);
void Watchdog_Init(void);
void Timer3A_Init(uint32_t period);

int main(void) {
    I2C_Init();        // Initialize I2C0 at 100kbps
    PortF_Init();      // So we can configure PF1�PF3 LEDs as outputs
    PortE_Init();      // Configure PE1 for DIP switch interrupt
    Watchdog_Init();   // Enable watchdog with reset capability
    Timer3A_Init(16000000); // Initialize 1Hz heartbeat (16MHz clock)

    while (1) {
        WATCHDOG0_ICR_R = 0xFFFFFFFF; // Feed the Watchdog
    }
}

/* PORT F: Drives the onboard Red (PF1), Blue (PF2), and Green (PF3) LEDs */
void PortF_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x20;               // Start clock for Port F
    while((SYSCTL_PRGPIO_R & 0x20) == 0){};  // Wait for PR register (Peripheral Ready)
    
    GPIO_PORTF_AMSEL_R &= ~0x0E;             // Disable analog on PF1-3
    GPIO_PORTF_PCTL_R  &= ~0x0000FFF0;       // Clear PCTL for GPIO mode
    GPIO_PORTF_AFSEL_R &= ~0x0E;             // Disable alt functions
    GPIO_PORTF_DIR_R   |=  0x0E;             // Set PF1-3 as outputs
    GPIO_PORTF_DEN_R   |=  0x0E;             // Enable digital on PF1-3
    GPIO_PORTF_DATA_BITS_R[0x0E] = 0;        // Start with LEDs OFF
}

/* PORT E: Configures PE1 as an edge-triggered interrupt input */
void PortE_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x10;               // Start clock for Port E
    while((SYSCTL_PRGPIO_R & 0x10) == 0){};  // Wait for Peripheral Ready
    
    GPIO_PORTE_DIR_R  &= ~0x02;              // PE1 is input
    GPIO_PORTE_DEN_R  |=  0x02;              // PE1 digital enable
    GPIO_PORTE_IS_R   &= ~0x02;              // Edge-sensitive
    GPIO_PORTE_IBE_R  &= ~0x02;              // Single edge trigger
    GPIO_PORTE_IEV_R  &= ~0x02;              // Falling edge trigger
    GPIO_PORTE_ICR_R   =  0x02;              // Clear existing flags
    GPIO_PORTE_IM_R   |=  0x02;              // Unmask interrupt (enable)

    // Set Port E Priority to 3 (Lower priority than Timer3A)
    // NVIC_PRI1 bits 15:13 control Port E
    NVIC_PRI1_R = (NVIC_PRI1_R & 0xFFFF00FF) | (3 << 13);
    NVIC_EN0_R |= (1U << 4);                 // Enable Interrupt 4 in NVIC
    GPIO_PORTE_PUR_R |= 0x02;                // Enable pull-up resistor
}

/* WATCHDOG: Reset system if not serviced within 1 second */
void Watchdog_Init(void) {
    SYSCTL_RCGCWD_R |= 0x01;                 // Clock WDT0
    while((SYSCTL_PRWD_R & 0x01) == 0){};    // Wait for Peripheral Ready
    
    WATCHDOG0_LOCK_R = 0x1ACCE551;           // Unlock WDT
    WATCHDOG0_LOAD_R = 16000000;             // 1 second timeout
    WATCHDOG0_CTL_R |= 0x03;                 // Enable Reset and Interrupt
    WATCHDOG0_LOCK_R = 0;                    // Re-lock WDT
}

/* TIMER 3A: Set 1Hz interrupt to increment counter on LEDs */
void Timer3A_Init(uint32_t period) {
    SYSCTL_RCGCTIMER_R |= 0x08;              // Clock Timer 3
    while((SYSCTL_PRTIMER_R & 0x08) == 0){}; // Wait for Peripheral Ready
    
    TIMER3_CTL_R  &= ~0x01;                  // Disable to allow config
    TIMER3_CFG_R   = 0x00;                   // 32-bit mode
    TIMER3_TAMR_R  = 0x02;                   // Periodic, countdown
    TIMER3_TAILR_R = period - 1;             // Set interval
    TIMER3_ICR_R   = 0x01;                   // Clear timeout flag
    TIMER3_IMR_R  |= 0x01;                   // Arm timeout interrupt

    // Set Timer3A Priority to 1 (Highest for our sys)
    // NVIC_PRI8 bits 31:29 control Timer3A
    NVIC_PRI8_R = (NVIC_PRI8_R & 0x00FFFFFF) | (1 << 29);
    NVIC_EN1_R |= (1U << 3);                 // Enable Interrupt 35 (Timer3A)
    TIMER3_CTL_R  |= 0x01;                   // Enable Timer 3A to implement new config
}

/* Timer3A ISR: Cycles through 0-7 and displays on RGB LEDs */
void Timer3A_Handler(void) {
    TIMER3_ICR_R = 0x01;                     // Acknowledge interrupt
    g_ledState = (g_ledState + 1) & 0x07;    // Cycle 0-7
    
    // Map bit 0->Red (PF1), bit 1->Blue (PF2), bit 2->Green (PF3)
    uint8_t mask = 0;
    if (g_ledState & 0x01) mask |= 0x02;
    if (g_ledState & 0x02) mask |= 0x04;
    if (g_ledState & 0x04) mask |= 0x08;
    
    GPIO_PORTF_DATA_BITS_R[0x0E] = mask;     // Update LEDs
}

/* Port E ISR: Triggered when DIP switch expander signals an input change */
void GPIOPortE_Handler(void) {
    GPIO_PORTE_ICR_R = 0x02;                 // Acknowledge PE1 interrupt
    
    // 1. Read the 8-bit value from the DIP switch via I2C
    uint8_t dipValue = I2C_Recv(I2C_ADDR_DIP);
    
    // 2. Split byte into nibbles (4-bits each)
    uint8_t lowNibble  = dipValue & 0x0F;
    uint8_t highNibble = (dipValue >> 4) & 0x0F;
    
    // 3. Convert to Common Anode bit patterns to work with my 7 segment displays (Invert CC table)
    uint8_t low_CA  = ~g_hexTo7Seg_CC[lowNibble];
    uint8_t high_CA = ~g_hexTo7Seg_CC[highNibble];
    
    // 4. Update the dual 7-segment displays via I2C
    I2C_Send1(I2C_ADDR_7SEG_LOW,  low_CA);
    I2C_Send1(I2C_ADDR_7SEG_HIGH, high_CA);
}
