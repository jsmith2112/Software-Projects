#include <stdint.h>
#include "I2C0.h"            // I2C driver for TM4C
#include "CortexM.h"         // StartCritical/EndCritical definitions
#include "tm4c123gh6pm.h"    // Full register map for the Tiva C
#include "my_procs_at_ece_uccs.h"
#include "my_defines_at_ece_uccs.h"

/* 
 * Jeffrey Smith - ECE 3440-001 Spring 2026
 * Lab 5: Integrated I2C Driver & Interrupt-Driven Control
 * This program use an I2C-based DIP switch to control a counter displayed 
 * on dual 7-segment displays and control sending to strings to an LCD display.
 * with 2 different functions and scrollability of text on display.
 * It features a Watchdog safety and a Timer heartbeat.
 */

// --- Global Variables (Marked volatile because they are modified in ISRs) ---
volatile uint8_t g_ledState = 0;       	// Tracks 3-bit pattern for RGB Heartbeat
volatile uint8_t g_countDirection = 0; 	// Direction toggle from DIP Switch 0
volatile uint8_t g_displayMode = 2;    	// Display selection from DIP Switches 1-2
volatile uint8_t g_displayBase = 10;  	// Selection (Dec/Hex) from DIP Switch 3
uint8_t g_currentCount = 0;           	// Main counter incremented in while(1)
volatile uint8_t g_nameFlip = 0;   			// Controlled by Switch 4
volatile uint8_t g_lcdClear = 0;  			// Controlled by Switch 5
// For Lab5
// --- New Goal Globals ---
volatile uint8_t g_scrollMode = 0; // Controlled by Switch 6 (0 = Normal Lab 4, 1 = Scrolling)
char g_scrollText[] = "Electrical and Computer Engineering at UCCS "; // 44 chars (including trailing space)
const int g_scrollLength = 44; // Matches the exact length of the string above



/* I2C Slave Addresses for PCF8574/MCP23008 IO Expanders */
#define I2C_ADDR_DIP        (0x20)     // Address for DIP Switch input bank
#define I2C_ADDR_7SEG_LOW   (0x21)     // Address for Right 7-segment display
#define I2C_ADDR_7SEG_HIGH  (0x22)     // Address for Left 7-segment display

// Initial estimates for 16MHz clock (Adjust these after scope measurement)
// Target: Short ~40us | Long ~1.6ms
#define LCD_SHORT_COUNT 57
#define LCD_LONG_COUNT  2400

#define I2C_ADDR_U1_CTRL    0x24  // Expander U1: Controls (RS on P0, E on P2) on LCD
#define I2C_ADDR_U2_DATA    0x23  // Expander U2: Data (D0-D7) on LCD
/* 
 * Lookup Table: Common Anode 7-Segment Patterns
 * Logic 0 = Segment ON, Logic 1 = Segment OFF
 * Index matches hex value (0-F)
 */
static const uint8_t g_hexTo7Seg_CA[16] = {
    0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 
    0x80, 0x90, 0x88, 0x83, 0xC6, 0xA1, 0x86, 0x8E
};

// Function Prototypes
void OutputNumTo7Seg(unsigned int number_, unsigned char mode_, unsigned char base_);
void PortF_Init(void);
void PortE_Init(void);
void Watchdog_Init(void);
void Timer3A_Init(uint32_t period);
// For Lab 5
void RotateString(char* str, int length, uint8_t direction);

// add LCD Function Prototypes
void PortA_Init(void);
void LCDSDel(void);
void LCDLDel(void);
void OutLCD(uint8_t data, uint8_t isCommand);
void InitLCD(void);
void OutputString(char* str);

int main(void) {
    I2C_Init();             // Enable I2C0 Module at 100kbps
		I2C_Send1(I2C_ADDR_DIP, 0xFF); // Set all pins as inputs on the PCF8574
		PortA_Init(); 					// Set up external signal on PA2
    PortF_Init();           // Setup Onboard RGB LEDs (PF1-PF3)
    PortE_Init();           // Setup External Interrupt on PE1 for DIP sensing
    Watchdog_Init();        // Prevent system hang (1s timeout)
    Timer3A_Init(16000000); // Initialize 1Hz periodic timer (Assuming 16MHz clock)
	
		InitLCD();                      // Initialize the hardware
    // OutputString("Yee Haw!");    // Test the LCD function
	
		uint32_t loopCount = 0; // Software counter for timing

    while (1) {
        // Feed the Watchdog timer to prevent a system reset
        WATCHDOG0_ICR_R = 0xFFFFFFFF; 
			
				// --- SCOPE CALIBRATION SECTION ---
        // These calls will toggle PA2 so you can see the pulses on the scope
				// For my scope easier to measure one at a time
        //LCDSDel(); // Measure this for ~40us
        //LCDLDel(); // Measure this for ~1.6ms
        // ---------------------------------
			
				        // Lab 4 & Lab 5 New Scroll Mode
        // --- LCD CONTROL SECTION ---
        if (g_lcdClear) {
            // Requirement: If switch is set, keep panel clear
            OutLCD(0x01, 0); 
            LCDLDel(); 
        } 
        else if (g_scrollMode == 1) {
            // --- NEW SCROLLING MODE ---
            
            // 1. Move to the beginning of the 1st line (Address 0x80)
            OutLCD(0x80, 0); 
            LCDSDel();
            
            // Print the first 16 characters of the scrolling string
            for(int i = 0; i < 16; i++) {
                OutLCD(g_scrollText[i], 1);
                LCDSDel();
            }

            // 2. Move to the beginning of the 2nd line (Address 0xC0)
            OutLCD(0xC0, 0); 
            LCDSDel();
            
            // Print the next 16 characters of the scrolling string
            for(int i = 16; i < 32; i++) {
                OutLCD(g_scrollText[i], 1);
                LCDSDel();
            }
        } 
        else {
            // --- LEGACY LAB 4 MODE ---
            // Move to middle of 1st line (Address 0x80 + offset)
            OutLCD(0x84, 0); 
            LCDSDel();
            if (g_nameFlip) OutputString("Smith"); else OutputString("Jeffrey");

            // Move to middle of 2nd line (Address 0xC0 + offset)
            OutLCD(0xC4, 0); 
            LCDSDel();
            if (g_nameFlip) OutputString("Jeffrey"); else OutputString("Smith");
        }


        // Update counter based on global direction set in GPIO ISR
        if (g_countDirection == 0) {
            g_currentCount++;
        } else {
            g_currentCount--;
        }

        // Update hardware displays via I2C driver
        OutputNumTo7Seg(g_currentCount, g_displayMode, g_displayBase);

        // Simple software delay for human readability (~4Hz update rate)
        for(volatile uint32_t i = 0; i < 400000; i++);
				
				loopCount++; // Increment loop counter every ~250ms

        // Trigger rotation every 2 loops (~500ms)
        if ((loopCount % 2) == 0) {
            // Only rotate if we are in Scroll Mode (Switch 6 set to 1)
            if (g_scrollMode == 1) {
                // Switch 4 (g_nameFlip) determines direction:
                // 0 = Rotate Right, 1 = Rotate Left
                RotateString(g_scrollText, g_scrollLength, g_nameFlip);
            } // end if for g_scrollMode
        } // end if for loop count
    } // end while
} // end main

/**
 * OutputNumTo7Seg: Updates I2C 7-Segment Displays
 * USES CRITICAL SECTIONS: Prevents the GPIO ISR from trying to use the I2C
 * bus while the main loop is mid-transmission (prevents bus collision).
 */
void OutputNumTo7Seg(unsigned int number_, unsigned char mode_, unsigned char base_) {
    uint8_t leftDigit, rightDigit;
    long sr; 

    // Extract digits based on selected base (10 for Decimal, 16 for Hex)
    rightDigit = number_ % base_;
    leftDigit  = (number_ / base_) % base_;

    // Disable interrupts to protect the I2C transaction sequence
    sr = StartCritical(); 

    if (mode_ == 0) {
        // Update Left display only
        I2C_Send1(I2C_ADDR_7SEG_HIGH, g_hexTo7Seg_CA[leftDigit]);
    } 
    else if (mode_ == 1) {
        // Update Right display only
        I2C_Send1(I2C_ADDR_7SEG_LOW, g_hexTo7Seg_CA[rightDigit]);
    } 
    else if (mode_ == 2) {
        // Update both displays
        I2C_Send1(I2C_ADDR_7SEG_HIGH, g_hexTo7Seg_CA[leftDigit]);
        I2C_Send1(I2C_ADDR_7SEG_LOW,  g_hexTo7Seg_CA[rightDigit]);
    }

    // Re-enable interrupts
    EndCritical(sr); 
}

/* 
 * GPIOPortE_Handler: Triggered by DIP switch change on PE1 
 * Reads the status of the I2C DIP Switch bank and updates control globals.
 */
void GPIOPortE_Handler(void) {
    GPIO_PORTE_ICR_R = 0x02; // Clear the interrupt flag for PE1
    
    // Perform I2C Read to get current switch positions
    uint8_t dipValue = I2C_Recv(I2C_ADDR_DIP);
    
    // Switch 0: Bit 0 determines Up/Down counting
    g_countDirection = (dipValue & 0x01);

    // Switch 1-2: Bits [2:1] determine display mode (Left/Right/Both)
    g_displayMode = (dipValue >> 1) & 0x03;
    if (g_displayMode > 2) g_displayMode = 2; // Safety clamp

    // Switch 3: Bit 3 determines numerical base
    g_displayBase = (dipValue & 0x08) ? 16 : 10;
	
		// Lab 4 Logic
    g_nameFlip = (dipValue & 0x10); // Switch 4 (Bit 4)
    g_lcdClear = (dipValue & 0x20); // Switch 5 (Bit 5)
	
		// For Lab 5
		// --- NEW GOAL: Switch 6 ---
    // Safely extract Bit 6 without affecting any other processing
    if (dipValue & 0x40) {
        g_scrollMode = 1;
    } else {
        g_scrollMode = 0;
    }
}

/* 
 * Timer3A_Handler: 1Hz Heartbeat 
 * Cycles through a 3-bit color pattern on the onboard RGB LEDs.
 */
void Timer3A_Handler(void) {
    TIMER3_ICR_R = 0x01;            			// Acknowledge Timer timeout
    g_ledState = (g_ledState + 1) & 0x07; // Increment state (0-7)
    
    uint8_t mask = 0;
    if (g_ledState & 0x01) mask |= 0x02; // Bit 0 -> Red LED (PF1)
    if (g_ledState & 0x02) mask |= 0x04; // Bit 1 -> Blue LED (PF2)
    if (g_ledState & 0x04) mask |= 0x08; // Bit 2 -> Green LED (PF3)
    
    // Use Bit-Masking through the data register to update only PF1-PF3
    GPIO_PORTF_DATA_BITS_R[0x0E] = mask;
}

// --- Initialization Functions ---

void PortA_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x01;            // Enable Clock for Port A
    while((SYSCTL_PRGPIO_R & 0x01) == 0){}; // Wait for stabilization
    GPIO_PORTA_DIR_R |= 0x04;             // Set PA2 as output
    GPIO_PORTA_DEN_R |= 0x04;             // Enable digital function for PA2
}

void PortF_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x20;            // Enable Clock for Port F
    while((SYSCTL_PRGPIO_R & 0x20) == 0){}; // Wait for stabilization
    GPIO_PORTF_DIR_R |= 0x0E;             // Set PF1, PF2, PF3 as outputs
    GPIO_PORTF_DEN_R |= 0x0E;             // Enable digital function
}

void PortE_Init(void) {
    SYSCTL_RCGCGPIO_R |= 0x10;            // Enable Clock for Port E
    while((SYSCTL_PRGPIO_R & 0x10) == 0){};// Wait for stabilization
    GPIO_PORTE_DIR_R  &= ~0x02;           // PE1 as input
    GPIO_PORTE_DEN_R  |=  0x02;           // Digital Enable PE1
    GPIO_PORTE_PUR_R  |=  0x02;           // Pull-up resistor for active-low switch
    GPIO_PORTE_IS_R   &= ~0x02;           // PE1 is edge-sensitive
    GPIO_PORTE_IBE_R  &= ~0x02;           // PE1 is not both edges
    GPIO_PORTE_IEV_R  &= ~0x02;           // PE1 falling edge trigger
    GPIO_PORTE_ICR_R   =  0x02;           // Clear initial flags
    GPIO_PORTE_IM_R   |=  0x02;           // Unmask (enable) interrupt for PE1
    
    // Set priority to 3 and enable IRQ 4 in NVIC
    NVIC_PRI1_R = (NVIC_PRI1_R & 0xFFFF00FF) | (3 << 13); 
    NVIC_EN0_R |= (1U << 4);
}

void Watchdog_Init(void) {
    SYSCTL_RCGCWD_R |= 0x01;              // Enable Watchdog 0 clock
    while((SYSCTL_PRWD_R & 0x01) == 0){};	// Wait for stabilization
    WATCHDOG0_LOCK_R = 0x1ACCE551;        // Unlock for configuration
    WATCHDOG0_LOAD_R = 16000000;          // 1 second at 16MHz
    WATCHDOG0_CTL_R |= 0x03;              // Enable reset and interrupt
    WATCHDOG0_LOCK_R = 0;                 // Re-lock
}

void Timer3A_Init(uint32_t period) {
    SYSCTL_RCGCTIMER_R |= 0x08;           		// Enable Timer 3 clock
    while((SYSCTL_PRTIMER_R & 0x08) == 0){};	// Wait for stabilization
    TIMER3_CTL_R  &= ~0x01;               		// Disable timer for setup
    TIMER3_CFG_R   = 0x00;                		// 32-bit mode
    TIMER3_TAMR_R  = 0x02;                		// Periodic mode
    TIMER3_TAILR_R = period - 1;          		// Set interval
    TIMER3_ICR_R   = 0x01;                		// Clear flag
    TIMER3_IMR_R  |= 0x01;                		// Enable timeout interrupt
    
    // Set priority 1 (higher than Port E) and enable in NVIC
    NVIC_PRI8_R = (NVIC_PRI8_R & 0x00FFFFFF) | (1 << 29); 
    NVIC_EN1_R |= (1U << 3);
    TIMER3_CTL_R |= 0x01;                 // Start Timer 3A
}

/**
 * LCDSDel: Short execution delay (Worst-case ~40-50us)
 */
void LCDSDel(void) {
    GPIO_PORTA_DATA_R |= 0x04;            // PA2 HIGH
    
    for(volatile uint32_t i = 0; i < LCD_SHORT_COUNT; i++) {
        WATCHDOG0_ICR_R = 0xFFFFFFFF;     // Service WDT inside loop
    }
    
    GPIO_PORTA_DATA_R &= ~0x04;           // PA2 LOW
}

/**
 * LCDLDel: Long execution delay (Worst-case ~1.6-2.0ms)
 */
void LCDLDel(void) {
    GPIO_PORTA_DATA_R |= 0x04;            // PA2 HIGH
    
    for(volatile uint32_t i = 0; i < LCD_LONG_COUNT; i++) {
        WATCHDOG0_ICR_R = 0xFFFFFFFF;     // Service WDT inside loop
    }
    
    GPIO_PORTA_DATA_R &= ~0x04;           // PA2 LOW
}


/**
 * Sends a byte of data or a command to an LCD via I2C.
 * @param data   The 8-bit value (character or command) to send.
 * @param isData Flag to determine Register Select (1 for data/RAM, 0 for command).
 */
void OutLCD(uint8_t data, uint8_t isData) {
    // Set RS bit: 0x01 if sending data, 0x00 if sending a command
    uint8_t rsBit = (isData == 1) ? 0x01 : 0x00;
    
    // Define Enable (E) pin states (assuming bit 2 of the control byte)
    uint8_t eHigh = 0x04; // Enable pin HIGH
    uint8_t eLow  = 0x00; // Enable pin LOW
    long sr;

    // Enter critical section (disable interrupts) to ensure I2C sequence is atomic
    sr = StartCritical(); 
    
    // Initialize control lines: Set RS and ensure Enable is LOW
    I2C_Send1(I2C_ADDR_U1_CTRL, rsBit | eLow);
    
    // Place the 8-bit data/command onto the LCD data bus
    I2C_Send1(I2C_ADDR_U2_DATA, data);
    
    // Pulse Enable HIGH to trigger the LCD to read the data bus
    I2C_Send1(I2C_ADDR_U1_CTRL, rsBit | eHigh);
    
    // Pull Enable LOW to complete the write cycle
    I2C_Send1(I2C_ADDR_U1_CTRL, rsBit | eLow);
    
    // Exit critical section (restore previous interrupt state)
    EndCritical(sr); 
}

void InitLCD(void) {
    // 2-Second Power-up Delay
    // This allows the LCD internal controller to stabilize after power-on.
    for(volatile uint32_t i = 0; i < 2600000; i++) {
        WATCHDOG0_ICR_R = 0xFFFFFFFF; // Feed the dog so we don't reset during boot
    }

    // Call delays AFTER each OutLCD call manually
    // Power-on sequence (Handshake)
    OutLCD(0x30, 0); LCDLDel(); // Long delay (>4.1ms)
    OutLCD(0x30, 0); LCDSDel(); // Short delay (>100us)
    OutLCD(0x30, 0); LCDSDel(); // Short delay (>100us)

    // Function Set: 8-bit, 2-line, 5x8 font
    OutLCD(0x38, 0); LCDSDel();

    // Cursor/Display Shift
    OutLCD(0x14, 0); LCDSDel();

    // Display ON, Cursor OFF
    OutLCD(0x0C, 0); LCDSDel();

    // Entry Mode: Increment Cursor
    OutLCD(0x06, 0); LCDSDel();

    // Clear Display (Requires long delay)
    OutLCD(0x01, 0); LCDLDel(); 
}

/**
 * OutputString: Iterates through a null-terminated string and 
 * outputs each character to the LCD.
 * str  Pointer to the character array (string)
 */
void OutputString(char* str) {
    // Iterate through the string until the null-terminator (\0) is reached
    while (*str != '\0') {
        
        // Call OutLCD for the current character
        // Second parameter is 1 because this is Character Data (RS=1)
        OutLCD(*str, 1);
			
				// Manual delay after each OutLCD call
        LCDSDel(); 
        
        // Increment the pointer to the next character in the array
        str++;
    }
}
/**
 * RotateString: Shifts the characters in a string array left or right.
 * @param str       Pointer to the character array.
 * @param length    The exact length of the string to rotate.
 * @param direction 0 for Right rotation, 1 for Left rotation.
 */
void RotateString(char* str, int length, uint8_t direction) {
    if (direction == 0) { // Rotate Right
        char lastChar = str[length - 1]; // Save the last character
        for (int i = length - 1; i > 0; i--) {
            str[i] = str[i - 1]; // Shift everything to the right
        }
        str[0] = lastChar; // Put the saved character at the front
    } 
    else { // Rotate Left
        char firstChar = str[0]; // Save the first character
        for (int i = 0; i < length - 1; i++) {
            str[i] = str[i + 1]; // Shift everything to the left
        }
        str[length - 1] = firstChar; // Put the saved character at the end
    }
}


