﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Jeffrey_Smith_CC6Q4
{
    internal class Question4
    {
        static void Main()
        {
            var numbers = new List<int> { 10000, 12000, 15000, 13000 };

            // TODO: Create CancellationTokenSource

            // Create CancellationTokenSource (cts)
            var cts = new CancellationTokenSource();


            // Task.Run to cancel after 2 seconds and print "User requested cancellation"
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                cts.Cancel();
                Console.WriteLine("User requested cancellation");
            });


            // Start stopwatch
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                // Sequential foreach loop
                // For each number:
                //    - Check cancellation
                //    - Print calculating message
                //    - Compute factorial
                //    - Print length
                foreach (var number in numbers)
                {
                    cts.Token.ThrowIfCancellationRequested();
                    Console.WriteLine($"Calculating factorial of {number}...");
                    // Compute factorial
                    BigInteger factorial = CalculateFactorial(number, cts.Token);
                    Console.WriteLine($"Length of factorial of {number} is {factorial.ToString().Length} digits.");
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Factorial computation was cancelled.");
            }

            // Stop stopwatch and print elapsed time
            stopwatch.Stop();
            Console.WriteLine($"Elapsed time: {stopwatch.ElapsedMilliseconds} ms");

            Console.WriteLine("Done.");
        }
        // Implement static BigInteger CalculateFactorial(int n, CancellationToken token)
        static BigInteger CalculateFactorial(int n, CancellationToken token)
        {
            BigInteger result = 1;
            for (int i = 2; i <= n; i++)
            {
                token.ThrowIfCancellationRequested();
                result *= i;
            }
            return result;
        }
    }
}
